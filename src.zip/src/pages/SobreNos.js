import React from 'react'
import NavBar from '../components/navbar/NavBar'
import Footer from '../components/footer/footer'

const SobreNos = () => {
  return (
    <div>
      <NavBar/>
      <h2>sobre</h2>
      <Footer/>
    </div>
  )
}

export default SobreNos
