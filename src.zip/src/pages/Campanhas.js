import React from 'react'
import NavBar from '../components/navbar/NavBar'
import Footer from '../components/footer/footer'

const Campanhas = () => {
  return (
    <div>
      <NavBar/>
      <h2>campanhas</h2>
      <Footer/>
    </div>
  )
}

export default Campanhas
