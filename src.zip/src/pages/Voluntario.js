import React from 'react'
import NavBar from '../components/navbar/NavBar'
import Footer from '../components/footer/footer'

const Voluntario = () => {
  return (
    <div>
      <NavBar/>
      <h2>voluntario</h2>
      <Footer/>
    </div>
  )
}

export default Voluntario
